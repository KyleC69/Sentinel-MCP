<?php
/**
 * Media Library Abilities.
 *
 * Upload, list, manage, and assign media files in the
 * WordPress media library via MCP.
 *
 * @package    MCPCOMAL
 * @author     José Conti <j.conti@joseconti.com>
 * @copyright  2026 José Conti
 * @license    GPL-2.0-or-later
 * @link       https://plugins.joseconti.com/product/mcp-content-manager-for-wordpress/
 */

defined( 'ABSPATH' ) || exit;

/*
 * Category
 * ─────────────────────────────────────────
 */

add_action(
	'wp_abilities_api_categories_init',
	function () {
		wp_register_ability_category(
			'mcpcomal-media',
			array(
				'label'       => __( 'Media Library', 'mcp-content-manager-lite' ),
				'description' => __( 'Upload, list, manage, and assign media files in the WordPress media library.', 'mcp-content-manager-lite' ),
			)
		);
	}
);

/*
 * Abilities
 * ─────────────────────────────────────────
 */

add_action(
	'wp_abilities_api_init',
	function () {
		/*
		 * LIST MEDIA
		 * ─────────────────────────────────────────
		 */

		wp_register_ability(
			'mcpcomal/list-media',
			array(
				'label'               => 'List media attachments',
				'category'            => 'mcpcomal-media',
				'description'         => 'All parameters optional. '
								. 'Lists media items from the WordPress Media Library with filters for MIME type, '
								. 'date range, and search. Returns ID, title, URL, dimensions, alt text, and thumbnail. '
								. 'Use this to find images before assigning them as featured images.',

				'input_schema'        => array(
					'type'       => 'object',
					'default'    => array(),
					'properties' => array(
						'search'      => array(
							'type'        => 'string',
							'description' => 'Search in attachment title and description.',
						),
						'mime_type'   => array(
							'type'        => 'string',
							'description' => 'Filter by MIME type prefix. E.g.: "image", "video", "audio", "application/pdf", or "any" for all.',
							'default'     => 'any',
						),
						'date_after'  => array(
							'type'        => 'string',
							'description' => 'Only media uploaded after this date (YYYY-MM-DD).',
						),
						'date_before' => array(
							'type'        => 'string',
							'description' => 'Only media uploaded before this date (YYYY-MM-DD).',
						),
						'count'       => array(
							'type'        => 'integer',
							'description' => 'Number of results per page (max 100). Alias: per_page is also accepted.',
							'default'     => 20,
						),
						'page'        => array(
							'type'        => 'integer',
							'description' => 'Page number for pagination.',
							'default'     => 1,
						),
						'orderby'     => array(
							'type'        => 'string',
							'description' => 'Order by field: "date", "title", or "modified".',
							'default'     => 'date',
							'enum'        => array( 'date', 'title', 'modified' ),
						),
						'order'       => array(
							'type'        => 'string',
							'description' => 'Sort direction: "ASC" or "DESC".',
							'default'     => 'DESC',
							'enum'        => array( 'ASC', 'DESC' ),
						),
					),
				),

				'output_schema'       => array(
					'type'                 => 'object',
					'additionalProperties' => true,
				),

				'execute_callback'    => function ( $input ) {
					return MCPCOMAL_Media_Manager::list_media( $input );
				},

				'permission_callback' => function () {
					return current_user_can( 'upload_files' );
				},

				'meta'                => array(
					'mcp' => array(
						'public'      => true,
						'annotations' => array(
							'readOnlyHint'    => true,
							'destructiveHint' => false,
							'idempotentHint'  => true,
							'openWorldHint'   => false,
						),
					),
				),
			)
		);

		/*
		 * UPLOAD MEDIA
		 * ─────────────────────────────────────────
		 */

		wp_register_ability(
			'mcpcomal/upload-media',
			array(
				'label'               => 'Upload media from URL',
				'category'            => 'mcpcomal-media',
				'description'         => 'Required: url (string). '
								. 'Downloads a file from a URL and adds it to the WordPress Media Library. '
								. 'Supports images, videos, audio, PDFs, and common document types. '
								. 'Optionally set title, alt text, caption, and attach to a post. '
								. 'After uploading, use mcpcomal/set-featured-image to assign it as a featured image.',

				'input_schema'        => array(
					'type'       => 'object',
					'default'    => array(),
					'required'   => array( 'url' ),
					'properties' => array(
						'url'         => array(
							'type'        => 'string',
							'description' => 'Full URL of the file to download and upload to the media library.',
						),
						'title'       => array(
							'type'        => 'string',
							'description' => 'Override the media title. If omitted, extracted from the filename.',
						),
						'alt_text'    => array(
							'type'        => 'string',
							'description' => 'Alt text for images (for accessibility and SEO).',
						),
						'caption'     => array(
							'type'        => 'string',
							'description' => 'Media caption.',
						),
						'description' => array(
							'type'        => 'string',
							'description' => 'Media description.',
						),
						'post_id'     => array(
							'type'        => 'integer',
							'description' => 'Attach the media to this post ID. 0 = unattached.',
							'default'     => 0,
						),
					),
				),

				'output_schema'       => array(
					'type'       => 'object',
					'properties' => array(
						'success'       => array( 'type' => 'boolean' ),
						'attachment_id' => array( 'type' => 'integer' ),
						'url'           => array( 'type' => 'string' ),
						'mime_type'     => array( 'type' => 'string' ),
						'message'       => array( 'type' => 'string' ),
					),
				),

				'execute_callback'    => function ( $input ) {
					return MCPCOMAL_Media_Manager::upload_media( $input );
				},

				'permission_callback' => function () {
					return current_user_can( 'upload_files' );
				},

				'meta'                => array(
					'mcp' => array(
						'public'      => true,
						'annotations' => array(
							'readOnlyHint'    => false,
							'destructiveHint' => false,
							'idempotentHint'  => false,
							'openWorldHint'   => false,
						),
					),
				),
			)
		);

		/*
		 * SET FEATURED IMAGE
		 * ─────────────────────────────────────────
		 */

		wp_register_ability(
			'mcpcomal/set-featured-image',
			array(
				'label'               => 'Set featured image',
				'category'            => 'mcpcomal-media',
				'description'         => 'Required: post_id (integer). '
								. 'Sets or removes the featured image (post thumbnail) for any post, page, or product. '
								. 'Pass attachment_id to set, or 0 / omit to remove the current featured image. '
								. 'Use mcpcomal/list-media or mcpcomal/upload-media first to get the attachment ID. '
								. 'Alias: id is also accepted instead of post_id.',

				'input_schema'        => array(
					'type'       => 'object',
					'default'    => array(),
					'properties' => array(
						'post_id'       => array(
							'type'        => 'integer',
							'description' => 'The post/page/product ID to set the featured image on.',
						),
						'id'            => array(
							'type'        => 'integer',
							'description' => 'Alias for post_id.',
						),
						'attachment_id' => array(
							'type'        => 'integer',
							'description' => 'The media attachment ID to use as featured image. Pass 0 or omit to remove.',
							'default'     => 0,
						),
					),
				),

				'output_schema'       => array(
					'type'       => 'object',
					'properties' => array(
						'success'       => array( 'type' => 'boolean' ),
						'post_id'       => array( 'type' => 'integer' ),
						'attachment_id' => array( 'type' => 'integer' ),
						'thumbnail_url' => array( 'type' => 'string' ),
						'message'       => array( 'type' => 'string' ),
					),
				),

				'execute_callback'    => function ( $input ) {
					$input['post_id'] = $input['post_id'] ?? $input['id'] ?? 0;
					return MCPCOMAL_Media_Manager::set_featured_image( $input );
				},

				'permission_callback' => function () {
					return current_user_can( 'upload_files' );
				},

				'meta'                => array(
					'mcp' => array(
						'public'      => true,
						'annotations' => array(
							'readOnlyHint'    => false,
							'destructiveHint' => false,
							'idempotentHint'  => true,
							'openWorldHint'   => false,
						),
					),
				),
			)
		);

		/*
		 * DELETE MEDIA
		 * ─────────────────────────────────────────
		 */

		wp_register_ability(
			'mcpcomal/delete-media',
			array(
				'label'               => 'Delete media attachment',
				'category'            => 'mcpcomal-media',
				'description'         => 'Required: attachment_id (integer). '
								. 'Deletes a media attachment from the WordPress Media Library. '
								. 'By default moves to trash. Set force=true for permanent deletion '
								. '(removes the file from disk). Use mcpcomal/list-media to find the attachment ID. '
								. 'Alias: id is also accepted instead of attachment_id.',

				'input_schema'        => array(
					'type'       => 'object',
					'default'    => array(),
					'properties' => array(
						'attachment_id' => array(
							'type'        => 'integer',
							'description' => 'The attachment ID to delete.',
						),
						'id'            => array(
							'type'        => 'integer',
							'description' => 'Alias for attachment_id.',
						),
						'force'         => array(
							'type'        => 'boolean',
							'description' => 'true = permanent deletion (removes files from disk). false = move to trash.',
							'default'     => false,
						),
					),
				),

				'output_schema'       => array(
					'type'       => 'object',
					'properties' => array(
						'success' => array( 'type' => 'boolean' ),
						'message' => array( 'type' => 'string' ),
					),
				),

				'execute_callback'    => function ( $input ) {
					$input['attachment_id'] = $input['attachment_id'] ?? $input['id'] ?? 0;
					return MCPCOMAL_Media_Manager::delete_media( $input );
				},

				'permission_callback' => function () {
					return current_user_can( 'upload_files' );
				},

				'meta'                => array(
					'mcp' => array(
						'public'      => true,
						'annotations' => array(
							'readOnlyHint'    => false,
							'destructiveHint' => true,
							'idempotentHint'  => true,
							'openWorldHint'   => false,
						),
					),
				),
			)
		);
	}
);
