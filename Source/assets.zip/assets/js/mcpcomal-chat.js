/**
 * Chat AI — Fullscreen chat application.
 *
 * Vanilla JS. Layout:
 * - Sidebar with conversation list + user menu popup
 * - Welcome screen with greeting + centered input
 * - Chat view with messages + bottom input
 * - Tool call accordions
 *
 * @package MCPCOMAL
 * @since   1.1.0
 */

( function () {
	'use strict';

	var config = window.mcpcomalChat || {};
	var i18n   = config.i18n || {};

	// ─── State ───────────────────────────────────────────────────

	var state = {
		conversations: [],
		activeConversationId: null,
		messages: [],
		isSending: false,
		searchOpen: false,
		sidebarOpen: false,
	};

	// ─── DOM Cache ───────────────────────────────────────────────

	var el = {};

	// ─── API Layer ───────────────────────────────────────────────

	var api = {
		call: function ( endpoint, method, body ) {
			method = method || 'GET';
			var opts = {
				method: method,
				headers: {
					'X-WP-Nonce': config.nonce,
					'Content-Type': 'application/json',
				},
			};
			if ( body ) {
				opts.body = JSON.stringify( body );
			}
			return fetch( config.restUrl + endpoint, opts ).then( function ( res ) {
				return res.json();
			} );
		},

		listConversations: function () {
			return api.call( 'conversations' );
		},

		createConversation: function ( provider, model ) {
			return api.call( 'conversations', 'POST', { provider: provider || '', model: model || '' } );
		},

		getConversation: function ( id ) {
			return api.call( 'conversations/' + id );
		},

		deleteConversation: function ( id ) {
			return api.call( 'conversations/' + id, 'DELETE' );
		},

		renameConversation: function ( id, title ) {
			return api.call( 'conversations/' + id, 'PATCH', { title: title } );
		},

		sendMessage: function ( conversationId, message ) {
			return api.call( 'send', 'POST', { conversation_id: conversationId, message: message } );
		},

		searchConversations: function ( query ) {
			return api.call( 'search?q=' + encodeURIComponent( query ) );
		},

		switchProvider: function ( conversationId, provider, model ) {
			return api.call( 'switch-provider', 'POST', { conversation_id: conversationId, provider: provider, model: model } );
		},
	};

	// ─── Markdown ────────────────────────────────────────────────

	var md = {
		render: function ( text ) {
			if ( ! text ) {
				return '';
			}
			try {
				var html = marked.parse( text, { breaks: true, gfm: true } );
				return DOMPurify.sanitize( html, { ADD_ATTR: [ 'target' ] } );
			} catch ( e ) {
				return esc( text );
			}
		},

		highlightAll: function ( container ) {
			if ( typeof hljs !== 'undefined' ) {
				container.querySelectorAll( 'pre code' ).forEach( function ( block ) {
					hljs.highlightElement( block );
				} );
			}
		},
	};

	// ─── Helpers ─────────────────────────────────────────────────

	function esc( str ) {
		if ( ! str ) {
			return '';
		}
		var d = document.createElement( 'div' );
		d.textContent = str;
		return d.innerHTML;
	}

	function getGreeting() {
		var h = new Date().getHours();
		var name = config.userName || '';
		var timeStr;
		if ( h < 12 ) {
			timeStr = 'Good morning';
		} else if ( h < 18 ) {
			timeStr = 'Good afternoon';
		} else {
			timeStr = 'Good evening';
		}
		return name ? timeStr + ', ' + name : timeStr;
	}

	function autoResize( textarea ) {
		textarea.style.height = 'auto';
		textarea.style.height = Math.min( textarea.scrollHeight, 200 ) + 'px';
	}

	function getModelList() {
		var list = [];
		var providers = config.providers || {};
		Object.keys( providers ).forEach( function ( pid ) {
			var p = providers[ pid ];
			if ( ! p.has_key ) {
				return;
			}
			var models = p.models || {};
			Object.keys( models ).forEach( function ( mid ) {
				list.push( {
					provider: pid,
					model: mid,
					providerLabel: p.label,
					modelLabel: models[ mid ],
					isDefault: pid === config.defaultProvider && mid === p.default,
				} );
			} );
		} );
		return list;
	}

	function getDefaultModel() {
		var list = getModelList();
		for ( var i = 0; i < list.length; i++ ) {
			if ( list[ i ].isDefault ) {
				return list[ i ];
			}
		}
		return list[0] || { provider: '', model: '', providerLabel: 'AI', modelLabel: 'Select model' };
	}

	function buildModelPicker( id ) {
		var def = getDefaultModel();
		return '<div class="mcpcomal-model-picker" id="' + id + '">' +
			'<button class="mcpcomal-model-picker-btn" type="button">' +
				'<span class="mcpcomal-model-picker-label">' + esc( def.modelLabel ) + '</span>' +
				'<span class="mcpcomal-model-picker-chevron dashicons dashicons-arrow-down-alt2"></span>' +
			'</button>' +
			'<div class="mcpcomal-model-picker-dropdown">' +
				buildModelDropdownItems() +
			'</div>' +
		'</div>';
	}

	function buildModelDropdownItems() {
		var providers = config.providers || {};
		var html = '';
		var first = true;

		Object.keys( providers ).forEach( function ( pid ) {
			var p = providers[ pid ];
			if ( ! first ) {
				html += '<div class="mcpcomal-model-picker-sep"></div>';
			}
			first = false;

			html += '<div class="mcpcomal-model-picker-group">' + esc( p.label ) + '</div>';

			if ( ! p.has_key ) {
				html += '<div class="mcpcomal-model-picker-no-key">-- No AI provider configured</div>';
				return;
			}

			var models = p.models || {};
			Object.keys( models ).forEach( function ( mid ) {
				var isDefault = pid === config.defaultProvider && mid === p.default;
				var cls = isDefault ? ' active' : '';
				html += '<div class="mcpcomal-model-picker-item' + cls + '" data-provider="' + pid + '" data-model="' + mid + '">' +
					'<span class="mcpcomal-check">&#10003;</span>' +
					'<span>' + esc( models[ mid ] ) + '</span>' +
				'</div>';
			} );
		} );
		return html;
	}

	// ─── UI ──────────────────────────────────────────────────────

	var ui = {
		init: function () {
			var app = document.getElementById( 'mcpcomal-chat-app' );
			if ( ! app ) {
				return;
			}
			app.removeAttribute( 'data-loading' );
			app.innerHTML = '';

			if ( ! config.hasApiKey ) {
				ui.renderNoApiKey( app );
				return;
			}

			app.innerHTML = ui.buildLayout();
			ui.cacheElements();
			handlers.bindAll();
			ui.loadConversations();
		},

		cacheElements: function () {
			el.sidebar         = document.querySelector( '.mcpcomal-chat-sidebar' );
			el.chatList        = document.querySelector( '.mcpcomal-chat-list' );
			el.searchBox       = document.querySelector( '.mcpcomal-chat-search-box' );
			el.searchInput     = document.querySelector( '.mcpcomal-chat-search-input' );
			el.welcome         = document.querySelector( '.mcpcomal-chat-welcome' );
			el.welcomeTextarea = document.getElementById( 'mcpcomal-welcome-textarea' );
			el.welcomePicker   = document.getElementById( 'mcpcomal-welcome-picker' );
			el.welcomeSendBtn  = document.getElementById( 'mcpcomal-welcome-send' );
			el.chatView        = document.querySelector( '.mcpcomal-chat-view' );
			el.messages        = document.querySelector( '.mcpcomal-chat-messages' );
			el.chatTextarea    = document.getElementById( 'mcpcomal-chat-textarea' );
			el.chatSendBtn     = document.getElementById( 'mcpcomal-chat-send' );
			el.chatPicker      = document.getElementById( 'mcpcomal-chat-picker' );
			el.usage           = document.querySelector( '.mcpcomal-chat-usage' );
			el.footer          = document.querySelector( '.mcpcomal-chat-sidebar-footer' );

			var def = getDefaultModel();
			state.selectedProvider = def.provider;
			state.selectedModel    = def.model;
		},

		buildLayout: function () {
			var userName = config.userName || 'Admin';
			var avatarHtml = config.userAvatar
				? '<img src="' + esc( config.userAvatar ) + '" alt="" class="mcpcomal-chat-user-avatar">'
				: '<div class="mcpcomal-chat-user-avatar-letter">' + esc( userName.charAt( 0 ).toUpperCase() ) + '</div>';

			return '' +
				/* ── Sidebar ── */
				'<div class="mcpcomal-chat-sidebar">' +
					'<div class="mcpcomal-chat-sidebar-header">' +
						'<button class="mcpcomal-chat-new-btn" type="button">' +
							'<span class="dashicons dashicons-plus-alt2"></span> ' + esc( i18n.newChat ) +
						'</button>' +
					'</div>' +
					'<div class="mcpcomal-chat-sidebar-nav">' +
						'<button class="mcpcomal-chat-nav-item" id="mcpcomal-search-toggle" type="button">' +
							'<span class="dashicons dashicons-search"></span> Search' +
						'</button>' +
						'<button class="mcpcomal-chat-nav-item active" id="mcpcomal-chats-toggle" type="button">' +
							'<span class="dashicons dashicons-format-chat"></span> Chats' +
						'</button>' +
					'</div>' +
					'<div class="mcpcomal-chat-search-box hidden" id="mcpcomal-search-box">' +
						'<input type="text" class="mcpcomal-chat-search-input" placeholder="' + esc( i18n.searchPlaceholder ) + '" autocomplete="off">' +
					'</div>' +
					'<div class="mcpcomal-chat-sidebar-label">Recent</div>' +
					'<div class="mcpcomal-chat-list"></div>' +
					'<div class="mcpcomal-chat-sidebar-footer">' +
						'<div class="mcpcomal-chat-popup-menu">' +
							'<a href="' + esc( config.adminUrl ) + '" class="mcpcomal-chat-popup-item">' +
								'<span class="dashicons dashicons-dashboard"></span> Dashboard' +
							'</a>' +
							'<a href="' + esc( config.adminUrl ) + 'options-connectors.php" class="mcpcomal-chat-popup-item">' +
								'<span class="dashicons dashicons-admin-generic"></span> AI Settings' +
							'</a>' +
							'<div class="mcpcomal-chat-popup-sep"></div>' +
							'<a href="' + esc( config.adminUrl ) + '" class="mcpcomal-chat-popup-item">' +
								'<span class="dashicons dashicons-arrow-left-alt"></span> ' + esc( i18n.backToAdmin ) +
							'</a>' +
						'</div>' +
						avatarHtml +
						'<span class="mcpcomal-chat-user-name">' + esc( userName ) + '</span>' +
						'<span class="mcpcomal-chat-footer-chevron dashicons dashicons-arrow-up-alt2"></span>' +
					'</div>' +
				'</div>' +
				'<div class="mcpcomal-chat-sidebar-overlay"></div>' +

				/* ── Main ── */
				'<div class="mcpcomal-chat-main">' +

					/* Welcome screen */
					'<div class="mcpcomal-chat-welcome">' +
						'<div class="mcpcomal-chat-welcome-center">' +
							'<div class="mcpcomal-chat-welcome-card">' +
								'<span class="mcpcomal-chat-welcome-icon dashicons dashicons-format-chat"></span>' +
								'<h1 class="mcpcomal-chat-welcome-title">' + esc( i18n.welcomeTitle ) + '</h1>' +
								'<p class="mcpcomal-chat-welcome-subtitle">' + esc( i18n.welcomeSubtitle ) + '</p>' +
								'<div class="mcpcomal-chat-suggestions">' +
									'<button class="mcpcomal-chat-suggestion" type="button">' + esc( i18n.welcomeSuggestion1 ) + '</button>' +
									'<button class="mcpcomal-chat-suggestion" type="button">' + esc( i18n.welcomeSuggestion2 ) + '</button>' +
									'<button class="mcpcomal-chat-suggestion" type="button">' + esc( i18n.welcomeSuggestion3 ) + '</button>' +
									'<button class="mcpcomal-chat-suggestion" type="button">' + esc( i18n.welcomeSuggestion4 ) + '</button>' +
								'</div>' +
							'</div>' +
						'</div>' +
						'<div class="mcpcomal-chat-welcome-bottom">' +
							'<div class="mcpcomal-chat-input-wrap">' +
								'<textarea id="mcpcomal-welcome-textarea" rows="1" placeholder="' + esc( i18n.inputPlaceholder ) + '"></textarea>' +
								'<button class="mcpcomal-chat-send-btn" id="mcpcomal-welcome-send" type="button">' +
									'<span class="dashicons dashicons-arrow-up-alt"></span>' +
								'</button>' +
							'</div>' +
							'<div class="mcpcomal-chat-welcome-bottom-meta">' +
								buildModelPicker( 'mcpcomal-welcome-picker' ) +
								'<span class="mcpcomal-chat-welcome-hint">Enter = send &middot; Shift+Enter = new line &middot; Esc = back</span>' +
							'</div>' +
						'</div>' +
					'</div>' +

					/* Chat view */
					'<div class="mcpcomal-chat-view hidden">' +
						'<div class="mcpcomal-chat-topbar">' +
							'<div class="mcpcomal-chat-topbar-left">' +
								'<button class="mcpcomal-chat-toggle-sidebar" type="button">' +
									'<span class="dashicons dashicons-menu"></span>' +
								'</button>' +
								buildModelPicker( 'mcpcomal-chat-picker' ) +
							'</div>' +
							'<span class="mcpcomal-chat-usage"></span>' +
						'</div>' +
						'<div class="mcpcomal-chat-messages"></div>' +
						'<div class="mcpcomal-chat-input">' +
							'<div class="mcpcomal-chat-input-wrap">' +
								'<textarea id="mcpcomal-chat-textarea" rows="1" placeholder="' + esc( i18n.inputPlaceholder ) + '"></textarea>' +
								'<button class="mcpcomal-chat-send-btn" id="mcpcomal-chat-send" type="button">' +
									'<span class="dashicons dashicons-arrow-up-alt"></span>' +
								'</button>' +
							'</div>' +
						'</div>' +
					'</div>' +

				'</div>';
		},

		renderNoApiKey: function ( container ) {
			container.innerHTML = '' +
				'<div class="mcpcomal-chat-no-key">' +
					'<span class="dashicons dashicons-warning"></span>' +
					'<p>' + esc( i18n.noApiKey ) + '</p>' +
					'<a href="' + esc( config.settingsUrl ) + '">' + esc( i18n.goToSettings ) + '</a>' +
				'</div>';
		},

		loadConversations: function () {
			api.listConversations().then( function ( data ) {
				if ( data.success ) {
					state.conversations = data.conversations || [];
					ui.renderChatList();
				}
			} );
		},

		renderChatList: function () {
			if ( ! el.chatList ) {
				return;
			}
			var convs = state.conversations;
			if ( ! convs.length ) {
				el.chatList.innerHTML = '<div class="mcpcomal-chat-empty-list">' + esc( i18n.noConversations ) + '</div>';
				return;
			}
			var html = '';
			convs.forEach( function ( c ) {
				var cls = parseInt( c.id ) === state.activeConversationId ? ' active' : '';
				html += '<div class="mcpcomal-chat-item' + cls + '" data-id="' + c.id + '">' +
					'<span class="mcpcomal-chat-item-title">' + esc( c.title ) + '</span>' +
					'<span class="mcpcomal-chat-item-delete" data-id="' + c.id + '">&times;</span>' +
				'</div>';
			} );
			el.chatList.innerHTML = html;
		},

		showWelcome: function () {
			state.activeConversationId = null;
			state.messages = [];
			if ( el.welcome ) {
				el.welcome.classList.remove( 'hidden' );
			}
			if ( el.chatView ) {
				el.chatView.classList.add( 'hidden' );
			}
			if ( el.messages ) {
				el.messages.innerHTML = '';
			}
			ui.renderChatList();
			ui.closeSidebar();
		},

		showChat: function ( convId ) {
			state.activeConversationId = parseInt( convId );
			if ( el.welcome ) {
				el.welcome.classList.add( 'hidden' );
			}
			if ( el.chatView ) {
				el.chatView.classList.remove( 'hidden' );
			}
			ui.renderChatList();
			ui.closeSidebar();
		},

		loadConversation: function ( id ) {
			ui.showChat( id );
			el.messages.innerHTML = '<div class="mcpcomal-typing"><div class="mcpcomal-typing-dot"></div><div class="mcpcomal-typing-dot"></div><div class="mcpcomal-typing-dot"></div></div>';

			api.getConversation( id ).then( function ( data ) {
				if ( data.success ) {
					state.messages = data.messages || [];
					state.selectedProvider = data.conversation.provider;
					state.selectedModel    = data.conversation.model;

					var list = getModelList();
					var found = list.filter( function ( m ) {
						return m.provider === data.conversation.provider && m.model === data.conversation.model;
					} );
					if ( found.length ) {
						document.querySelectorAll( '.mcpcomal-model-picker-label' ).forEach( function ( lbl ) {
							lbl.textContent = found[0].modelLabel;
						} );
						document.querySelectorAll( '.mcpcomal-model-picker-item' ).forEach( function ( it ) {
							it.classList.remove( 'active' );
						} );
						document.querySelectorAll( '.mcpcomal-model-picker-item[data-provider="' + data.conversation.provider + '"][data-model="' + data.conversation.model + '"]' ).forEach( function ( it ) {
							it.classList.add( 'active' );
						} );
					}

					ui.renderMessages();
				}
			} );
		},

		renderMessages: function () {
			if ( ! el.messages ) {
				return;
			}
			var html = '';
			state.messages.forEach( function ( msg ) {
				if ( msg.role === 'user' ) {
					html += '<div class="mcpcomal-msg-user">' + esc( msg.content ) + '</div>';
				} else if ( msg.role === 'assistant' ) {
					html += ui.renderAssistantMessage( msg );
				}
			} );
			el.messages.innerHTML = html;
			md.highlightAll( el.messages );
			ui.bindToolToggles();
			ui.scrollToBottom();
		},

		renderAssistantMessage: function ( msg ) {
			var html = '<div class="mcpcomal-msg-assistant">' + md.render( msg.content ) + '</div>';

			if ( msg.tool_calls && msg.tool_calls.length ) {
				msg.tool_calls.forEach( function ( tc ) {
					html += ui.renderToolCall( tc );
				} );
			}

			return html;
		},

		renderToolCall: function ( tc ) {
			var statusClass = 'success';
			var statusIcon = '&#10003;';
			if ( tc.type === 'confirmation_required' ) {
				statusClass = 'confirmation';
				statusIcon = '&#9888;';
			} else if ( ! tc.success ) {
				statusClass = 'error';
				statusIcon = '&#10007;';
			}

			var inputJson = '';
			var outputJson = '';
			try { inputJson = JSON.stringify( tc.input, null, 2 ); } catch ( e ) { inputJson = String( tc.input ); }
			try { outputJson = JSON.stringify( tc.output, null, 2 ); } catch ( e ) { outputJson = String( tc.output ); }

			return '' +
				'<div class="mcpcomal-tool-call">' +
					'<div class="mcpcomal-tool-call-header">' +
						'<span class="mcpcomal-tool-call-status ' + statusClass + '">' + statusIcon + '</span>' +
						'<span class="mcpcomal-tool-call-name">' + esc( tc.tool ) + '</span>' +
						'<span class="mcpcomal-tool-call-chevron">&#9654;</span>' +
					'</div>' +
					'<div class="mcpcomal-tool-call-body">' +
						'<div><strong>Input:</strong><pre>' + esc( inputJson ) + '</pre></div>' +
						'<div style="margin-top:8px;"><strong>Output:</strong><pre>' + esc( outputJson ) + '</pre></div>' +
					'</div>' +
				'</div>';
		},

		bindToolToggles: function () {
			el.messages.querySelectorAll( '.mcpcomal-tool-call-header' ).forEach( function ( h ) {
				if ( ! h.dataset.bound ) {
					h.dataset.bound = '1';
					h.addEventListener( 'click', function () {
						h.parentElement.classList.toggle( 'open' );
					} );
				}
			} );
		},

		showTyping: function () {
			if ( ! el.messages ) {
				return;
			}
			var t = document.createElement( 'div' );
			t.className = 'mcpcomal-typing mcpcomal-typing-indicator';
			t.innerHTML = '<div class="mcpcomal-typing-dot"></div><div class="mcpcomal-typing-dot"></div><div class="mcpcomal-typing-dot"></div>';
			el.messages.appendChild( t );
			ui.scrollToBottom();
		},

		hideTyping: function () {
			var t = el.messages ? el.messages.querySelector( '.mcpcomal-typing-indicator' ) : null;
			if ( t ) {
				t.remove();
			}
		},

		scrollToBottom: function () {
			if ( el.messages ) {
				el.messages.scrollTop = el.messages.scrollHeight;
			}
		},

		updateUsage: function ( tokensIn, tokensOut ) {
			if ( el.usage && ( tokensIn || tokensOut ) ) {
				el.usage.textContent = ( tokensIn || 0 ) + ' / ' + ( tokensOut || 0 ) + ' ' + esc( i18n.tokens );
			}
		},

		openSidebar: function () {
			if ( el.sidebar ) {
				el.sidebar.classList.add( 'open' );
			}
			state.sidebarOpen = true;
		},

		closeSidebar: function () {
			if ( el.sidebar ) {
				el.sidebar.classList.remove( 'open' );
			}
			state.sidebarOpen = false;
		},
	};

	// ─── Handlers ────────────────────────────────────────────────

	var handlers = {
		bindAll: function () {
			document.querySelector( '.mcpcomal-chat-new-btn' ).addEventListener( 'click', function () {
				ui.showWelcome();
				if ( el.welcomeTextarea ) {
					el.welcomeTextarea.focus();
				}
			} );

			document.getElementById( 'mcpcomal-search-toggle' ).addEventListener( 'click', function () {
				if ( state.searchOpen ) {
					handlers.closeSearch();
				} else {
					handlers.openSearch();
				}
			} );

			document.getElementById( 'mcpcomal-chats-toggle' ).addEventListener( 'click', function () {
				handlers.closeSearch();
				ui.loadConversations();
			} );

			if ( el.searchInput ) {
				var searchTimeout;
				el.searchInput.addEventListener( 'input', function () {
					clearTimeout( searchTimeout );
					var q = el.searchInput.value;
					searchTimeout = setTimeout( function () {
						if ( q.length >= 2 ) {
							api.searchConversations( q ).then( function ( data ) {
								if ( data.success ) {
									state.conversations = data.conversations || [];
									ui.renderChatList();
								}
							} );
						} else if ( q === '' ) {
							ui.loadConversations();
						}
					}, 300 );
				} );
			}

			el.chatList.addEventListener( 'click', function ( e ) {
				var del = e.target.closest( '.mcpcomal-chat-item-delete' );
				if ( del ) {
					e.stopPropagation();
					handlers.deleteConversation( parseInt( del.dataset.id ) );
					return;
				}
				var item = e.target.closest( '.mcpcomal-chat-item' );
				if ( item ) {
					ui.loadConversation( parseInt( item.dataset.id ) );
				}
			} );

			if ( el.welcomeSendBtn ) {
				el.welcomeSendBtn.addEventListener( 'click', handlers.sendFromWelcome );
			}
			if ( el.welcomeTextarea ) {
				el.welcomeTextarea.addEventListener( 'keydown', function ( e ) {
					if ( e.key === 'Enter' && ! e.shiftKey ) {
						e.preventDefault();
						handlers.sendFromWelcome();
					}
				} );
				el.welcomeTextarea.addEventListener( 'input', function () {
					autoResize( el.welcomeTextarea );
				} );
			}

			document.querySelectorAll( '.mcpcomal-chat-suggestion' ).forEach( function ( btn ) {
				btn.addEventListener( 'click', function () {
					if ( el.welcomeTextarea ) {
						el.welcomeTextarea.value = btn.textContent;
					}
					handlers.sendFromWelcome();
				} );
			} );

			if ( el.chatSendBtn ) {
				el.chatSendBtn.addEventListener( 'click', handlers.sendFromChat );
			}
			if ( el.chatTextarea ) {
				el.chatTextarea.addEventListener( 'keydown', function ( e ) {
					if ( e.key === 'Enter' && ! e.shiftKey ) {
						e.preventDefault();
						handlers.sendFromChat();
					}
				} );
				el.chatTextarea.addEventListener( 'input', function () {
					autoResize( el.chatTextarea );
				} );
			}

			handlers.bindPicker( el.welcomePicker );
			handlers.bindPicker( el.chatPicker );

			document.addEventListener( 'click', function ( e ) {
				document.querySelectorAll( '.mcpcomal-model-picker.open' ).forEach( function ( p ) {
					if ( ! p.contains( e.target ) ) {
						p.classList.remove( 'open' );
					}
				} );
			} );

			var toggleBtn = document.querySelector( '.mcpcomal-chat-toggle-sidebar' );
			if ( toggleBtn ) {
				toggleBtn.addEventListener( 'click', function () {
					state.sidebarOpen ? ui.closeSidebar() : ui.openSidebar();
				} );
			}

			var overlay = document.querySelector( '.mcpcomal-chat-sidebar-overlay' );
			if ( overlay ) {
				overlay.addEventListener( 'click', ui.closeSidebar );
			}

			if ( el.footer ) {
				el.footer.addEventListener( 'click', function ( e ) {
					if ( e.target.closest( '.mcpcomal-chat-popup-item' ) ) {
						return;
					}
					el.footer.classList.toggle( 'open' );
				} );

				document.addEventListener( 'click', function ( e ) {
					if ( ! el.footer.contains( e.target ) ) {
						el.footer.classList.remove( 'open' );
					}
				} );
			}

			document.addEventListener( 'keydown', function ( e ) {
				if ( e.key === 'Escape' ) {
					if ( state.sidebarOpen ) {
						ui.closeSidebar();
					} else if ( state.activeConversationId ) {
						ui.showWelcome();
					}
				}
				if ( ( e.ctrlKey || e.metaKey ) && e.key === 'n' ) {
					e.preventDefault();
					ui.showWelcome();
					if ( el.welcomeTextarea ) {
						el.welcomeTextarea.focus();
					}
				}
			} );
		},

		bindPicker: function ( pickerEl ) {
			if ( ! pickerEl ) {
				return;
			}
			var btn = pickerEl.querySelector( '.mcpcomal-model-picker-btn' );
			if ( btn ) {
				btn.addEventListener( 'click', function ( e ) {
					e.stopPropagation();
					document.querySelectorAll( '.mcpcomal-model-picker.open' ).forEach( function ( p ) {
						if ( p !== pickerEl ) {
							p.classList.remove( 'open' );
						}
					} );
					pickerEl.classList.toggle( 'open' );
				} );
			}
			pickerEl.querySelectorAll( '.mcpcomal-model-picker-item' ).forEach( function ( item ) {
				item.addEventListener( 'click', function () {
					var provider = item.dataset.provider;
					var model    = item.dataset.model;
					state.selectedProvider = provider;
					state.selectedModel    = model;

					document.querySelectorAll( '.mcpcomal-model-picker-label' ).forEach( function ( lbl ) {
						lbl.textContent = item.textContent;
					} );

					document.querySelectorAll( '.mcpcomal-model-picker-item' ).forEach( function ( it ) {
						it.classList.remove( 'active' );
					} );
					document.querySelectorAll( '.mcpcomal-model-picker-item[data-provider="' + provider + '"][data-model="' + model + '"]' ).forEach( function ( it ) {
						it.classList.add( 'active' );
					} );

					pickerEl.classList.remove( 'open' );

					if ( state.activeConversationId ) {
						api.switchProvider( state.activeConversationId, provider, model );
					}
				} );
			} );
		},

		openSearch: function () {
			state.searchOpen = true;
			if ( el.searchBox ) {
				el.searchBox.classList.remove( 'hidden' );
			}
			document.getElementById( 'mcpcomal-search-toggle' ).classList.add( 'active' );
			document.getElementById( 'mcpcomal-chats-toggle' ).classList.remove( 'active' );
			if ( el.searchInput ) {
				el.searchInput.focus();
			}
		},

		closeSearch: function () {
			state.searchOpen = false;
			if ( el.searchBox ) {
				el.searchBox.classList.add( 'hidden' );
			}
			if ( el.searchInput ) {
				el.searchInput.value = '';
			}
			document.getElementById( 'mcpcomal-search-toggle' ).classList.remove( 'active' );
			document.getElementById( 'mcpcomal-chats-toggle' ).classList.add( 'active' );
		},

		sendFromWelcome: function () {
			if ( state.isSending ) {
				return;
			}
			var message = el.welcomeTextarea ? el.welcomeTextarea.value.trim() : '';
			if ( ! message ) {
				return;
			}

			state.isSending = true;
			el.welcomeTextarea.value = '';
			autoResize( el.welcomeTextarea );

			api.createConversation( state.selectedProvider, state.selectedModel ).then( function ( data ) {
				if ( data.success ) {
					ui.showChat( data.conversation.id );
					handlers.doSend( parseInt( data.conversation.id ), message );
				} else {
					state.isSending = false;
					alert( data.error || i18n.errorGeneric );
				}
			} ).catch( function () {
				state.isSending = false;
			} );
		},

		sendFromChat: function () {
			if ( state.isSending || ! state.activeConversationId ) {
				return;
			}
			var message = el.chatTextarea ? el.chatTextarea.value.trim() : '';
			if ( ! message ) {
				return;
			}

			state.isSending = true;
			el.chatTextarea.value = '';
			autoResize( el.chatTextarea );

			handlers.doSend( state.activeConversationId, message );
		},

		doSend: function ( conversationId, message ) {
			if ( el.messages ) {
				el.messages.insertAdjacentHTML( 'beforeend', '<div class="mcpcomal-msg-user">' + esc( message ) + '</div>' );
			}
			ui.showTyping();

			if ( el.chatSendBtn ) {
				el.chatSendBtn.disabled = true;
			}

			api.sendMessage( conversationId, message ).then( function ( data ) {
				ui.hideTyping();
				state.isSending = false;
				if ( el.chatSendBtn ) {
					el.chatSendBtn.disabled = false;
				}

				if ( data.success ) {
					state.messages.push( data.message );

					if ( el.messages ) {
						el.messages.insertAdjacentHTML( 'beforeend', ui.renderAssistantMessage( data.message ) );
						md.highlightAll( el.messages );
						ui.bindToolToggles();
					}
					ui.scrollToBottom();
					ui.updateUsage( data.message.tokens_in, data.message.tokens_out );

					if ( data.conversation ) {
						var found = false;
						state.conversations.forEach( function ( c, idx ) {
							if ( parseInt( c.id ) === conversationId ) {
								state.conversations[ idx ].title = data.conversation.title;
								state.conversations[ idx ].updated_at = data.conversation.updated_at;
								found = true;
							}
						} );
						if ( ! found ) {
							state.conversations.unshift( data.conversation );
						}
						ui.renderChatList();
					}
				} else {
					if ( el.messages ) {
						el.messages.insertAdjacentHTML( 'beforeend',
							'<div class="mcpcomal-msg-error"><span class="dashicons dashicons-warning"></span> ' + esc( data.error || i18n.errorGeneric ) + '</div>'
						);
					}
					ui.scrollToBottom();
				}

				if ( el.chatTextarea ) {
					el.chatTextarea.focus();
				}
			} ).catch( function () {
				ui.hideTyping();
				state.isSending = false;
				if ( el.chatSendBtn ) {
					el.chatSendBtn.disabled = false;
				}
				if ( el.messages ) {
					el.messages.insertAdjacentHTML( 'beforeend',
						'<div class="mcpcomal-msg-error"><span class="dashicons dashicons-warning"></span> ' + esc( i18n.errorGeneric ) + '</div>'
					);
				}
				ui.scrollToBottom();
			} );
		},

		deleteConversation: function ( id ) {
			if ( ! confirm( i18n.deleteConfirm ) ) {
				return;
			}
			api.deleteConversation( id ).then( function ( data ) {
				if ( data.success ) {
					state.conversations = state.conversations.filter( function ( c ) {
						return parseInt( c.id ) !== id;
					} );
					ui.renderChatList();
					if ( state.activeConversationId === id ) {
						ui.showWelcome();
					}
				}
			} );
		},
	};

	// ─── Init ────────────────────────────────────��───────────────

	document.addEventListener( 'DOMContentLoaded', ui.init );

} )();
